import React, { Component } from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import Svg, { Path, Stop, Defs, LinearGradient } from "react-native-svg";
import Navbar from "../symbols/Navbar";
import DeviceBezelsIPhoneXsDisplayShape from "../symbols/DeviceBezelsIPhoneXsDisplayShape";

export default class Player1 extends Component {
  render() {
    return (
      <View style={styles.root}>
        <View style={styles.backgroundPattern}>
          <View style={styles.rectangle}>
            <Svg
              viewBox={"-0 -0 492.6416781507329 299.4145353491142"}
              style={styles.path2}
            >
              <Defs>
                <LinearGradient id="gradient3" x1={0} x2={102} y1={0} y2={101}>
                  <Stop offset="0.00" stopColor="rgba(48,35,174,1)" />
                  <Stop
                    offset="1.00"
                    stopColor="rgba(200,109,215,0.3004132699275363)"
                  />
                </LinearGradient>
              </Defs>
              <Path
                strokeWidth={0}
                fill={"url(#gradient3)"}
                fillOpacity={0.9}
                strokeOpacity={0.9}
                d={
                  "M13.83 125.80 L295.13 299.41 L492.64 149.59 L492.64 0.00 L0.00 0.00 L13.83 125.80 Z"
                }
              />
            </Svg>
          </View>
        </View>
        <Image
          source={require("../assets/images/39dadff1704ca12558ddf5bb9cb278436a0360a6.png")}
          style={styles.podcastArtwork}
        />
        <View style={styles.rectangle1} />
        <View style={styles.player}>
          <View style={styles.nameEpisode}>
            <Text style={styles.iHaventBeenThis}>
              I haven’t been this cautious in six years
            </Text>
            <Text style={styles.episode147}>EPISODE - 147</Text>
          </View>
          <View style={styles.moreIcon}>
            <Svg viewBox={"-0 -0 18.44000000000005 4.44"} style={styles.path}>
              <Path
                strokeWidth={0}
                fill={"rgba(255,255,255,1)"}
                d={
                  "M9.22 4.44 C7.99 4.44 7.00 3.45 7.00 2.22 C7.00 0.99 7.99 0.00 9.22 0.00 C10.45 0.00 11.44 0.99 11.44 2.22 C11.44 3.45 10.45 4.44 9.22 4.44 Z M16.22 4.44 C14.99 4.44 14.00 3.45 14.00 2.22 C14.00 0.99 14.99 0.00 16.22 0.00 C17.45 0.00 18.44 0.99 18.44 2.22 C18.44 3.45 17.45 4.44 16.22 4.44 Z M2.22 4.44 C0.99 4.44 0.00 3.45 0.00 2.22 C0.00 0.99 0.99 0.00 2.22 0.00 C3.45 0.00 4.44 0.99 4.44 2.22 C4.44 3.45 3.45 4.44 2.22 4.44 Z"
                }
              />
            </Svg>
          </View>
          <View style={styles.scrollBar}>
            <Svg viewBox={"-1 -1 273 6"} style={styles.line2}>
              <Path
                strokeWidth={2}
                fill={"transparent"}
                stroke={"rgba(255,255,255,1)"}
                fillOpacity={0.2}
                strokeOpacity={0.2}
                d={"M1.46 2.00 L270.00 2.00 "}
              />
            </Svg>
            <Text style={styles.style}>1:02:52</Text>
            <Text style={styles.style1}>01:43:00</Text>
            <Svg viewBox={"-1 -1 157 6"} style={styles.line2Copy}>
              <Path
                strokeWidth={2}
                fill={"transparent"}
                stroke={"rgba(80,227,194,1)"}
                d={"M1.00 2.00 L153.85 2.00 "}
              />
            </Svg>
            <Svg viewBox={"-0 -0 10 10"} style={styles.oval}>
              <Path
                strokeWidth={0}
                fill={"rgba(255,255,255,1)"}
                d={
                  "M5.00 10.00 C7.76 10.00 10.00 7.76 10.00 5.00 C10.00 2.24 7.76 0.00 5.00 0.00 C2.24 0.00 0.00 2.24 0.00 5.00 C0.00 7.76 2.24 10.00 5.00 10.00 Z"
                }
              />
            </Svg>
          </View>
          <View style={styles.controls}>
            <View style={styles.fastForward}>
              <Svg
                viewBox={"-1.2 -1.2 28.75604395604394 21.8"}
                style={styles.path1}
              >
                <Path
                  strokeWidth={4.8}
                  fill={"transparent"}
                  stroke={"rgba(255,255,255,1)"}
                  d={
                    "M15.58 19.40 L26.36 10.90 L15.58 2.40 L15.58 19.40 Z M2.40 19.40 L13.18 10.90 L2.40 2.40 L2.40 19.40 Z"
                  }
                />
              </Svg>
            </View>
            <View style={styles.reverse}>
              <Svg
                viewBox={"-1.2 -1.2 28.75604395604396 21.8"}
                style={styles.path2}
              >
                <Path
                  strokeWidth={4.8}
                  fill={"transparent"}
                  stroke={"rgba(255,255,255,1)"}
                  d={
                    "M15.58 19.40 L26.36 10.90 L15.58 2.40 L15.58 19.40 Z M2.40 19.40 L13.18 10.90 L2.40 2.40 L2.40 19.40 Z"
                  }
                />
              </Svg>
            </View>
            <View style={styles.repeat}>
              <Svg viewBox={"-1 -1 22 26"} style={styles.path3}>
                <Path
                  strokeWidth={4}
                  fill={"transparent"}
                  stroke={"rgba(255,255,255,1)"}
                  d={
                    "M16.00 10.00 L20.00 6.00 L16.00 2.00 M2.00 12.00 L2.00 10.00 L6.00 6.00 L20.00 6.00 M6.00 16.00 L2.00 20.00 L6.00 24.00 M20.00 14.00 L20.00 16.00 L16.00 20.00 L2.00 20.00 "
                  }
                />
              </Svg>
            </View>
            <View style={styles.shuffle}>
              <Svg viewBox={"-1 -1 21 22"} style={styles.path4}>
                <Path
                  strokeWidth={4}
                  fill={"transparent"}
                  stroke={"rgba(255,255,255,1)"}
                  d={
                    "M14.00 2.00 L19.00 2.00 L19.00 7.00 M19.00 2.00 L2.00 19.00 M19.00 15.00 L19.00 20.00 L14.00 20.00 M19.00 20.00 L13.00 14.00 M7.00 8.00 L2.00 3.00 "
                  }
                />
              </Svg>
            </View>
          </View>
        </View>
        <Navbar style={styles.navbar} />
        <DeviceBezelsIPhoneXsDisplayShape
          style={styles.deviceBezelsIPhoneXsDisplayShape}
        />
        <View style={styles.group2}>
          <Svg viewBox={"-0 -0 60 60"} style={styles.oval1}>
            <Path
              strokeWidth={0}
              fill={"rgba(217,45,45,1)"}
              d={
                "M30.00 60.00 C46.57 60.00 60.00 46.57 60.00 30.00 C60.00 13.43 46.57 0.00 30.00 0.00 C13.43 0.00 0.00 13.43 0.00 30.00 C0.00 46.57 13.43 60.00 30.00 60.00 Z"
              }
            />
          </Svg>
        </View>
        <Text style={styles.nowPlaying}>Now Playing</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgba(255,255,255,1)"
  },
  backgroundPattern: {
    top: "-0.25%",
    left: "0.00%",
    width: "100.00%",
    height: "31.90%",
    position: "absolute"
  },
  rectangle: {
    top: "0.00%",
    left: "0.00%",
    width: "100.00%",
    height: "100.00%",
    backgroundColor: "transparent",
    position: "absolute",
    overflow: "hidden"
  },
  path2: {
    top: "-7.06%",
    left: "-5.01%",
    width: "120.04%",
    height: "128.24%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  podcastArtwork: {
    top: "10.22%",
    left: "0.00%",
    width: "100.27%",
    height: "46.31%",
    backgroundColor: "transparent",
    position: "absolute"
  },
  rectangle1: {
    top: "56.53%",
    left: "0.00%",
    width: "100.27%",
    height: "33.25%",
    backgroundColor: "rgba(134,109,204,1)",
    position: "absolute"
  },
  player: {
    top: "60.59%",
    left: "7.47%",
    width: "85.33%",
    height: "17.00%",
    position: "absolute"
  },
  nameEpisode: {
    top: "0.00%",
    left: "0.00%",
    width: "93.75%",
    height: "22.46%",
    position: "absolute"
  },
  iHaventBeenThis: {
    top: "0.00%",
    left: "0.00%",
    backgroundColor: "transparent",
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 18,
    fontFamily: "sfprodisplay-medium",
    lineHeight: 2
  },
  episode147: {
    top: "35.48%",
    left: "0.00%",
    backgroundColor: "transparent",
    color: "rgba(255,255,255,1)",
    position: "absolute",
    opacity: 0.5,
    fontSize: 14,
    fontFamily: "poppins-regular"
  },
  moreIcon: {
    top: "3.62%",
    left: "92.97%",
    width: "5.94%",
    height: "3.62%",
    position: "absolute"
  },
  path: {
    top: "0.00%",
    left: "2.63%",
    width: "97.05%",
    height: "88.80%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  scrollBar: {
    top: "34.06%",
    left: "0.31%",
    width: "99.69%",
    height: "22.46%",
    position: "absolute"
  },
  line2: {
    top: "9.68%",
    left: "15.36%",
    width: "85.58%",
    height: "19.35%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  style: {
    top: "45.16%",
    left: "0.00%",
    backgroundColor: "transparent",
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 12,
    fontFamily: "poppins-semibold"
  },
  style1: {
    top: "45.16%",
    left: "84.95%",
    backgroundColor: "transparent",
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 12,
    fontFamily: "poppins-semibold",
    textAlign: "right"
  },
  line2Copy: {
    top: "9.68%",
    left: "-0.31%",
    width: "49.22%",
    height: "19.35%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  oval: {
    top: "0.00%",
    left: "46.39%",
    width: "3.13%",
    height: "32.26%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  controls: {
    top: "84.06%",
    left: "4.06%",
    width: "91.88%",
    height: "15.94%",
    position: "absolute"
  },
  fastForward: {
    top: "13.64%",
    left: "73.48%",
    width: "8.16%",
    height: "77.27%",
    position: "absolute"
  },
  path1: {
    top: "-7.06%",
    left: "-5.00%",
    width: "119.82%",
    height: "128.24%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  reverse: {
    top: "13.64%",
    left: "17.69%",
    width: "8.15%",
    height: "77.27%",
    position: "absolute",
    transform: [
      {
        rotate: "-180deg"
      }
    ]
  },
  repeat: {
    top: "0.00%",
    left: "93.88%",
    width: "6.12%",
    height: "100.00%",
    position: "absolute",
    opacity: 0.2
  },
  path3: {
    top: "-4.55%",
    left: "-5.56%",
    width: "122.22%",
    height: "118.18%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  shuffle: {
    top: "9.09%",
    left: "0.00%",
    width: "5.78%",
    height: "81.82%",
    position: "absolute",
    opacity: 0.2
  },
  path4: {
    top: "-5.56%",
    left: "-5.88%",
    width: "123.53%",
    height: "122.22%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  navbar: {
    top: "89.78%",
    left: "-0.27%",
    width: "100.00%",
    height: "10.10%",
    backgroundColor: "transparent",
    position: "absolute"
  },
  deviceBezelsIPhoneXsDisplayShape: {
    top: "0.00%",
    left: "0.00%",
    width: "100.00%",
    height: "100.00%",
    backgroundColor: "transparent",
    position: "absolute"
  },
  group2: {
    top: "80.79%",
    left: "79.47%",
    width: "16.00%",
    height: "7.39%",
    position: "absolute"
  },
  oval1: {
    top: "0.00%",
    left: "0.00%",
    width: "100.00%",
    height: "100.00%",
    backgroundColor: "transparent",
    position: "absolute",
    borderColor: "transparent"
  },
  nowPlaying: {
    top: "5.67%",
    left: "7.47%",
    backgroundColor: "transparent",
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 19,
    fontFamily: "sfprodisplay-semibold"
  }
});
